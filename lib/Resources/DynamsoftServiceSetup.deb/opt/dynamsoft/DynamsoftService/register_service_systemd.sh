#!/bin/sh
cd /opt/dynamsoft/DynamsoftService

systemctl stop dynamsoft.service
systemctl disable dynamsoft.service
systemctl daemon-reload

systemctl enable /opt/dynamsoft/DynamsoftService/dynamsoft.service
systemctl start dynamsoft.service

/opt/dynamsoft/DynamsoftService/AutoStartMgr "/opt/dynamsoft/DynamsoftService/DebInstallCertCheck&"



